<div class="nav-item dropdown d-flex">
    <a href="cuenta.php#carrito" class="nav-link nav-item" style="margin-right: 10px;" id="shoppingItem">

        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-shopping-cart" width="40" height="40" viewBox="0 0 24 24" stroke-width="1.5" stroke="#000000" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <circle cx="6" cy="19" r="2" />
            <circle cx="17" cy="19" r="2" />
            <path d="M17 17h-11v-14h-2" />
            <path d="M6 5l14 1l-1 7h-13" />
        </svg> 7
    </a>
    <a class="nav-item align-items-start" href="cuenta.php">
        <img class="border border-dark rounded-circle" style="width: 45px; margin: 5px;" src="img/user.png" alt="User">
    </a>
    <a class="nav-link dropdown-toggle" href="#" id="username" role="button" data-bs-toggle="dropdown" aria-expanded="false">
        UsersName
    </a>
    <ul class="dropdown-menu" aria-labelledby="Dropdown">
        <li><a class="dropdown-item" href="cuenta.php">Mi cuenta</a></li>
        <li><a class="dropdown-item" href="#">Mis direcciones</a></li>
        <li><a class="dropdown-item" href="#">Pedidos</a></li>
        <li><a class="dropdown-item" href="#">Carrito</a></li>
        <li>
            <hr class="dropdown-divider">
        </li>
        <li><a class="dropdown-item" href="#">Cerrar sesión</a></li>
    </ul>

</div>