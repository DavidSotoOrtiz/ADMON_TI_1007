<?php $in=1; include("includes/header.php");  ?>
<div class="col-8 col-md-10 lateral bg_contenido position-relative overflow-auto">

    <div class="container-fluid contenido">
        <div class="container salto">
            <h4 class="position-relative">Selecciona el producto a editar o agrega uno nuevo
                <a class="btn d-inline-flex position-absolute start-100 translate-middle-x" data-bs-toggle="modal" data-bs-target="#agregarItem">
                    <h5 class="align-middle" style="padding: 2px; color: #681212">Agregar </h5><img src="img/add.png" alt="Agregar" style="width: 30px; height: 30px; margin-left: 5px; margin-right: 30px;">
                </a>
            </h4>

        </div>
        <div class="row scroll_column salto">
            <div class="col-sm-12 col-lg-4">
                <div class="card-body rounded" style="background-color: #ececec; margin: 5px">
                    <h5 class="card-title">sushi básico</h5>
                    <img class="img-fluid img_item" src="../img/item.jpg" alt="item">
                    <p class="card-text"></p>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edicionItem">
                        Editar
                    </button>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card-body rounded" style="background-color: #ececec; margin: 5px">
                    <h5 class="card-title">sushi básico</h5>
                    <img class="img-fluid img_item" src="../img/item.jpg" alt="item">
                    <p class="card-text"></p>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edicionItem">
                        Editar
                    </button>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card-body rounded" style="background-color: #ececec; margin: 5px">
                    <h5 class="card-title">sushi básico</h5>
                    <img class="img-fluid img_item" src="../img/item.jpg" alt="item">
                    <p class="card-text"></p>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edicionItem">
                        Editar
                    </button>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card-body rounded" style="background-color: #ececec; margin: 5px">
                    <h5 class="card-title">sushi básico</h5>
                    <img class="img-fluid img_item" src="../img/item.jpg" alt="item">
                    <p class="card-text"></p>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edicionItem">
                        Editar
                    </button>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card-body rounded" style="background-color: #ececec; margin: 5px">
                    <h5 class="card-title">sushi básico</h5>
                    <img class="img-fluid img_item" src="../img/item.jpg" alt="item">
                    <p class="card-text"></p>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edicionItem">
                        Editar
                    </button>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card-body rounded" style="background-color: #ececec; margin: 5px">
                    <h5 class="card-title">sushi básico</h5>
                    <img class="img-fluid img_item" src="../img/item.jpg" alt="item">
                    <p class="card-text"></p>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edicionItem">
                        Editar
                    </button>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card-body rounded" style="background-color: #ececec; margin: 5px">
                    <h5 class="card-title">sushi básico</h5>
                    <img class="img-fluid img_item" src="../img/item.jpg" alt="item">
                    <p class="card-text"></p>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edicionItem">
                        Editar
                    </button>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card-body rounded" style="background-color: #ececec; margin: 5px">
                    <h5 class="card-title">sushi básico</h5>
                    <img class="img-fluid img_item" src="../img/item.jpg" alt="item">
                    <p class="card-text"></p>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edicionItem">
                        Editar
                    </button>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card-body rounded" style="background-color: #ececec; margin: 5px">
                    <h5 class="card-title">sushi básico</h5>
                    <img class="img-fluid img_item" src="../img/item.jpg" alt="item">
                    <p class="card-text"></p>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edicionItem">
                        Editar
                    </button>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card-body rounded" style="background-color: #ececec; margin: 5px">
                    <h5 class="card-title">sushi básico</h5>
                    <img class="img-fluid img_item" src="../img/item.jpg" alt="item">
                    <p class="card-text"></p>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edicionItem">
                        Editar
                    </button>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card-body rounded" style="background-color: #ececec; margin: 5px">
                    <h5 class="card-title">sushi básico</h5>
                    <img class="img-fluid img_item" src="../img/item.jpg" alt="item">
                    <p class="card-text"></p>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edicionItem">
                        Editar
                    </button>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card-body rounded" style="background-color: #ececec; margin: 5px">
                    <h5 class="card-title">sushi básico</h5>
                    <img class="img-fluid img_item" src="../img/item.jpg" alt="item">
                    <p class="card-text"></p>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edicionItem">
                        Editar
                    </button>
                </div>
            </div>
            <div class="col-sm-12 col-lg-4">
                <div class="card-body rounded" style="background-color: #ececec; margin: 5px">
                    <h5 class="card-title">sushi básico</h5>
                    <img class="img-fluid img_item" src="../img/item.jpg" alt="item">
                    <p class="card-text"></p>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#edicionItem">
                        Editar
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
</div>

<?php include("includes/footer.php") ?>
