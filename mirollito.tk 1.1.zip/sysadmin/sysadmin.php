<?php $in=0; include("includes/header.php");  ?>
            <div class="col-8 col-md-10 fullHeight bg_contenido position-relative">

                <h3 class="position-absolute top-50 start-50 translate-middle">Bienvenido al sysadmin de Rollito</h3>
            </div>
        </div>
    </div>

    </div>
<?php include('includes/footer.php')?>